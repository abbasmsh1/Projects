#include "SearchEngine.h"
int main()
{
	SearchEngine google;//Initialise Search Engine
	google.Menu();//Call Driver Function

}