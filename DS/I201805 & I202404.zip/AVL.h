/*AI Batch 2021 DS Project by Asna Muzafar [20i-1085] and Abbas Mustafa [20i-2404]*/
#include "Term_Info.h"
using namespace std;
class AVL_Node
{
public:
	Term_Info data;//Data Member
	AVL_Node* left;//Data Member
	AVL_Node* right;//Data Member
	int height;//Data Member
	AVL_Node()//Constructor
	{
		left = right = NULL;
		height = 0;
	}
	AVL_Node(Term_Info d)//Parametrized Constructor with one Data Member
	{
		data = d;
		height = 0;
		left = right = NULL;
	}
	AVL_Node(Term_Info d,int h)//Parametrized Constructor with one Data Member
	{
		data = d;
		height = h;
		left = right = NULL;
	}
};
class AVL
{
public:
	AVL_Node* root;//Data Member
	AVL()//Constructor
	{
		root = NULL;
	}
	int height(AVL_Node* N)//Function to find height of a node
	{
		if (N == NULL)
			return 0;
		return N->height;
	}
	int max(int a, int b)//function to find greater of two values
	{
		return (a > b) ? a : b;
	}
	AVL_Node* newNode(string term)//Function to create a new Node
	{
		AVL_Node* node = new AVL_Node();
		node->data.term = term;
		node->left = NULL;
		node->right = NULL;
		node->height = 1; // New Node is Initially added as Leaf
		return(node);
	}
	AVL_Node* rightRotate(AVL_Node* y)//Function to Right Rotate a Node
	{
		AVL_Node* x = y->left;
		AVL_Node* T2 = x->right;
		x->right = y;
		y->left = T2;
		y->height = max(height(y->left),
			height(y->right)) + 1;
		x->height = max(height(x->left),
			height(x->right)) + 1;
		return x;
	}
	AVL_Node* leftRotate(AVL_Node* x)//Function to Left Rotate a Node
	{
		AVL_Node* y = x->right;
		AVL_Node* T2 = y->left;
		y->left = x;
		x->right = T2;
		x->height = max(height(x->left),
			height(x->right)) + 1;
		y->height = max(height(y->left),
			height(y->right)) + 1;
		return y;
	}
	int getBalance(AVL_Node* N)//Function to get the Balance Factor
	{
		if (N == NULL)
			return 0;
		return height(N->left) - height(N->right);
	}
	AVL_Node* insert(AVL_Node* node, string key)//Function to Insert a new Node
	{
		if (node == NULL)
			return(newNode(key));
		if (key < node->data.term)
			node->left = insert(node->left, key);
		else if (key > node->data.term)
			node->right = insert(node->right, key);
		else 
			return node;
		node->height = 1 + max(height(node->left),
			height(node->right));
		int balance = getBalance(node);
		if (balance > 1 && key < node->left->data.term)
			return rightRotate(node);
		if (balance < -1 && key > node->right->data.term)
			return leftRotate(node);
		if (balance > 1 && key > node->left->data.term)
		{
			node->left = leftRotate(node->left);
			return rightRotate(node);
		}
		if (balance < -1 && key < node->right->data.term)
		{
			node->right = rightRotate(node->right);
			return leftRotate(node);
		}
		return node;
	}
	void preOrder(AVL_Node* root)//Function to Print the Tree in PreOrder
	{
		if (root != NULL)
		{
			cout << root->data;
			preOrder(root->left);
			preOrder(root->right);
		}
	}
	AVL_Node* search(string s)//Function to Search in the Tree
	{
		AVL_Node* head = root;
		while (head != NULL)
		{
			if (head->data.term == s)
			{
				return head;
			}
			else if (head->data.term > s)
			{
				head = head->left;
			}
			else
			{
				head = head->right;
			}
		}
		return head;

	}
	friend void operator<<(ostream& os, AVL& d)//Cout Operator Overloaded
	{
		d.preOrder(d.root);
	}
};