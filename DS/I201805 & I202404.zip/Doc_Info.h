/*AI Batch 2021 DS Project by Asna Muzafar [20i-1085] and Abbas Mustafa [20i-2404]*/
#include <iostream>
#include <string>
using namespace std;
class Doc_Info
{
public:
	Doc_Info()//Constructor
	{
		Doc_ID = freq = 0;
	}
	Doc_Info(int id)//Parametrized Constructor for ID 
	{
		Doc_ID = id;
		freq = 0;
	}
	Doc_Info(int id,int f)//Parametrized Constructor for both data members
	{
		Doc_ID = id;
		freq = f;
	}
	int Doc_ID;//Data Member
	int freq;//Data Member
	bool operator == (Doc_Info d)//== Overloaded
	{
		return (this->Doc_ID == d.Doc_ID);
	}
	bool operator > (Doc_Info d)//> Overloaded
	{
		return (this->freq < d.freq);
	}
	bool operator < (Doc_Info d)//< Overloaded
	{
		return (this->freq > d.freq);
	}
	bool operator >= (Doc_Info d)//>= Overloaded
	{
		return (this->freq <= d.freq);
	}
	bool operator <= (Doc_Info d)//<= Overloaded
	{
		return (this->freq >= d.freq);
	}
	friend ostream& operator<<(ostream& os, const Doc_Info& d)//Cout Overloaded
	{
		os << "doc : " << d.Doc_ID << "\n\t frequency : " << d.freq << endl;
		return os;
	}
	

};