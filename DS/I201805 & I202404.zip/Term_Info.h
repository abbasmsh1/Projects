/*AI Batch 2021 DS Project by Asna Muzafar [20i-1085] and Abbas Mustafa [20i-2404]*/
#include"LinkedList.h"
#include "Doc_Info.h"
using namespace std;
class Term_Info
{
public:
	string term;//Data Member
	LinkedList<Doc_Info> docs;//Data Member
	Term_Info()//Constructor 
	{
		term = "";
	}
	Term_Info(string s)//Parametrized Constructor 
	{
		term = s;
	}
	void InsertDoc(Doc_Info d)//Insert New Document Function 
	{
		docs.insert(d);
	}
	void InsertDoc(int id,int freq)//Insert New Document using ID and Frequency Function 
	{
		Doc_Info d(id, freq);
		docs.insert(d);
	}
	friend ostream& operator<<(ostream& os, const Term_Info& d)//Cout Overloaded
	{
		os << "Term : " << d.term <<"\nDoc List is\n"<<d.docs << endl;
		return os;
	}


};