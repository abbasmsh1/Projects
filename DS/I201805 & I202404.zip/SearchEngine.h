/*AI Batch 2021 DS Project by Asna Muzafar [20i-1085] and Abbas Mustafa [20i-2404]*/

#include"AVL.h"
#include <fstream>
using namespace std;
template <class T>
void sort(LinkedList<T> l)//Function to Sort LinkedList
{
	Node<T>* head = l.root;
	Node<T>* r = head;
	while (r != NULL)
	{
		head = r;
		while (head->next != NULL)
		{
			if (head->data > head->next->data)
			{
				T temp = head->data;
				head->data = head->next->data;
				head->next->data = temp;
			}
			head = head->next;
		}
		r = r->next;
	}
	cout << l;
}
class SearchEngine
{
private:
	AVL Index;//Data Member
	AVL_Node* root;//Data Member
	static int ID;//Data Member to update Document ID
public:
	SearchEngine()//Constructor
	{
		root = NULL;
		cout << "\n\n\t\t\t\t\t Welcome to Google\t\t\n\n\n";
		cin.ignore();
	}
	void Menu()//Menu Function --> Acts as Driver Function
	{
		cin.ignore();
		int choice=0;
		while (choice > -1)
		{
			cout << "\n\n\n\n";
			cout << "-> TO ENTER A DOCUMENT PRESS 1\n";
			cout << "-> TO ENTER MULTIPLE DOCUMENTS PRESS 2\n";
			cout << "-> TO SEARCH FOR A QUERY PRESS 3\n";
			cout << "-> TO EXIT PRESS 4\n";
			cin >> choice;
			switch (choice)
			{
			case 1://Enter Single Document
			{
				string name;
				cout << "\tEnter Document\n";
				cin >> name;
				cin.ignore();
				Add_Doc_to_Index(name);
				break;
			}
			case 2://Enter Multiple Documents
			{
				int n;
				cout << "Enter Number of files\n";
				cin >> n;
				string* list = new string[n];
				for (int i = 0; i < n; i++)
				{
					cout << "\tEnter Document "<< i+1<<endl;
					cin >> list[i];
					cin.ignore();
				}
				Create_Index(list, n);
				break;
			}
			case 3://Enter Search Query
			{
				if (Index.root == NULL)
				{
					cout << "Index is Empty\n";
					break;
				}
				string q;
				cout << "Enter Query\n";
				//cin >> q;
				cin.ignore();
				getline(cin, q);
				
				Search_Index(q);
				break;
			}
			 case 4 ://Exit Search Engine
			{
				 exit(0);
			}
			 default://Default Case for any other input
				 cout << "Incorrect Choice Please reEnter\n";
				 break;
			}
		}
	}
	void Create_Index(string d[], int n)//Use List of file names and quantity and add them to tree in a loop
	{
		for (int i = 0; i < n; i++)
			Add_Doc_to_Index(d[i]);
	}
	void Add_Doc_to_Index(string f)//Take Document Name open the file, parse it and add it to the tree
	{
		string path = "E:\\3rdSem\\DS\\DS Project\\DS Project\\" + f + ".txt";
		fstream file;
		string temp;
		ID++;
		file.open(path, ios::in || ios::out);
		if (file)//File Reading, Parsing and insertion into tree 
		{
			cout << "file at " << path << " opened successfully\n";
			while (!file.eof())
			{
				file >> temp;
				cout << temp<<endl;
				if (Index.search(temp) == NULL)
				{
					root = Index.insert(root, temp);
					Index.root = root;
					Doc_Info d(ID, 1);
					Index.search(temp)->data.InsertDoc(d);
				}
				else
				{
					Doc_Info d(ID, 1);
					if (Index.search(temp)->data.docs.search(d))
					{
						Index.search(temp)->data.docs.search(d)->data.freq++;
					}
					else
					{
						Index.search(temp)->data.InsertDoc(d);
					}
				}
			}
		}
		else
		{
			cout << "File Opening Unsuccessfull\n";
		}
	}
	void Search_Index(string q)//Search Query in the Tree
	{
		LinkedList<Doc_Info> doc;
		LinkedList<string> l;
		string s = "";
		for (int i = 0; i < q.length(); i++)//Create List of words from given String
		{
			if (q[i] == ' ')
			{
				l.insert(s);
				s = "";
			}
			else
			{
				s = s + q[i];
			}
		}
		l.insert(s);
		Node<string>* n = l.root;
		while (n != NULL)//Search for each Word in Tree and Add to Output List 
		{
			AVL_Node* a = Index.search(n->data);
			if (Index.search(n->data) == NULL)
			{
				cout << n->data << " Not found\n";
			}
			else
			{
				doc=doc.append(a->data.docs);
			}
			n = n->next;
		}
		sort(doc);//Sort and Print Output List
	}
};
int SearchEngine::ID = 0;