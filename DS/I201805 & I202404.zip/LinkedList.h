/*AI Batch 2021 DS Project by Asna Muzafar [20i-1085] and Abbas Mustafa [20i-2404]*/
#include <iostream>
using namespace std;
template <class T>
class Node//Linked List Node Declaration
{
public:
	T data;//Data Member
	Node* next; //Data Member
	Node()//Constructor
	{
		next = NULL;
	}
	Node(T d)//Parametrized Constructor
	{
		data = d;
		next = NULL;
	}
};
template <class T>
class LinkedList
{
public:
	Node<T>* root;//Data Member
	LinkedList()//Constructor
	{
		root = NULL;
	}
	void insert(T d)//Insert Node Function
	{
		Node<T>* temp = new Node<T>(d);
		if (root == NULL)
			root = temp;
		else
		{
			Node<T>* head = root;
			while (head->next != NULL)
			{
				head = head->next;
			}
			head->next = temp;
		}
	}
	void print()//Print LinkedList Function
	{
		Node<T>* head = root;
		while (head != NULL)
		{
			cout << head->data << endl;
			head = head->next;
		}
		cout << "\b\b\n";
		
	}
	Node<T>* search(T d)//Search in LinkedList Function
	{
		Node<T>* head = root;
		while (head != NULL)
		{
			if (head->data == d)
				return head;
			head = head->next;
		}
		return NULL;
	}
	LinkedList<T> append(LinkedList<T> d)//Append LinkedList to Existing LinkedList Function
	{
		LinkedList<T> temp;
		Node<T>* head = root;
		while (head != NULL)
		{
			temp.insert(head->data);
			head = head->next;
		}
		head = d.root;
		while (head != NULL)
		{
			//if(search(head->data)!=NULL)
				temp.insert(head->data);
			head = head->next;
		}
		return temp;
	}
	friend ostream& operator<<(ostream& os, const LinkedList<T>& d)//Cout Overloaded
	{
		Node<T>* head = d.root;
		if (d.root == NULL)
		{
			cout << "Empty\n";
		}
		else
		while (head != NULL)
		{
			os << head->data << endl;
			head = head->next;
		}
		
		return os;
	}
};