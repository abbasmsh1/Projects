//============================================================================
// Name        : Abbas_20I2404.cpp
// Author      : Sibt ul Hussain
// Version     :
// Copyright   : (c) Reserved
// Description : Basic 2D game of Centipede...
//============================================================================

#ifndef CENTIPEDE_CPP_
#define CENTIPEDE_CPP_
//#include "Board.h"
#include "util.h"
#include <iostream>
#include<string>
#include <cstdlib>
#include <fstream> 
#include<cmath> // for basic math functions such as cos, sin, sqrt
using namespace std;

// seed the random numbers generator by current time (see the documentation of srand for further help)...

/* Function sets canvas size (drawing area) in pixels...
 *  that is what dimensions (x and y) your game will have
 *  Note that the bottom-left coordinate has value (0,0) and top-right coordinate has value (width-1,height-1)
 * */

string pcolor[4];
void Dice(int toss);
int roll()
{
	int toss ;
		toss = rand() % 6 + 1;
		Dice(toss);
	
	return toss;
}
void boardYELLOW()
{
	DrawSquare( 1180 , 2000 ,110,colors[BLACK]);
	DrawSquare( 1185 , 2005 ,100,colors[WHITE]);
	DrawSquare( 1020 , 2000 ,110,colors[BLACK]);
	DrawSquare( 1025 , 2005 ,100,colors[WHITE]);
	DrawSquare( 860 , 2000 ,110,colors[BLACK]);
	DrawSquare( 865 , 2005 ,100,colors[WHITE]);
	DrawSquare( 1180 , 1875 ,110,colors[BLACK]);
	DrawSquare( 1185 , 1880 ,100,colors[DARK_GOLDEN_ROD]);
	DrawSquare( 1020 , 1875 ,110,colors[BLACK]);
	DrawSquare( 1025 , 1880 ,100,colors[DARK_GOLDEN_ROD]);
	DrawSquare( 860 , 1875 ,110,colors[BLACK]);
	DrawSquare( 865 , 1880 ,100,colors[WHITE]);
	DrawSquare( 1180 , 1750 ,110,colors[BLACK]);
	DrawSquare( 1185 , 1755 ,100,colors[WHITE]);
	DrawSquare( 1020 , 1750 ,110,colors[BLACK]);
	DrawSquare( 1025 , 1755 ,100,colors[DARK_GOLDEN_ROD]);
	DrawSquare( 860 , 1750 ,110,colors[BLACK]);
	DrawSquare( 865 , 1755 ,100,colors[SLATE_GRAY]);
	DrawSquare( 1180 , 1625 ,110,colors[BLACK]);
	DrawSquare( 1185 , 1630 ,100,colors[WHITE]);
	DrawSquare( 1020 , 1625 ,110,colors[BLACK]);
	DrawSquare( 1025 , 1630 ,100,colors[DARK_GOLDEN_ROD]);
	DrawSquare( 860 , 1625 ,110,colors[BLACK]);
	DrawSquare( 865 , 1630 ,100,colors[WHITE]);
	DrawSquare( 1180 , 1500 ,110,colors[BLACK]);
	DrawSquare( 1185 , 1505 ,100,colors[WHITE]);
	DrawSquare( 1020 , 1500 ,110,colors[BLACK]);
	DrawSquare( 1025 , 1505 ,100,colors[DARK_GOLDEN_ROD]);
	DrawSquare( 860 , 1500 ,110,colors[BLACK]);
	DrawSquare( 865 , 1505 ,100,colors[WHITE]);
	DrawSquare( 1180 , 1375 ,110,colors[BLACK]);
	DrawSquare( 1185 , 1380 ,100,colors[WHITE]);
	DrawSquare( 1020 , 1375 ,110,colors[BLACK]);
	DrawSquare( 1025 , 1380 ,100,colors[DARK_GOLDEN_ROD]);
	DrawSquare( 860 , 1375 ,110,colors[BLACK]);
	DrawSquare( 865 , 1380 ,100,colors[WHITE]);
}
 void boardGREEN()
 {
 	DrawSquare( 1180 , 50 ,110,colors[BLACK]);
	DrawSquare( 1185 , 55 ,100,colors[WHITE]);
	DrawSquare( 1020 , 50 ,110,colors[BLACK]);
	DrawSquare( 1025 , 55 ,100,colors[WHITE]);
	DrawSquare( 860 , 50 ,110,colors[BLACK]);
	DrawSquare( 865 , 55 ,100,colors[WHITE]);
	DrawSquare( 1180 , 165 ,110,colors[BLACK]);
	DrawSquare( 1185 , 170 ,100,colors[WHITE]);
	DrawSquare( 1020 , 165 ,110,colors[BLACK]);
	DrawSquare( 1025 , 170 ,100,colors[GREEN]);
	DrawSquare( 860 , 165 ,110,colors[BLACK]);
	DrawSquare( 865 , 170 ,100,colors[GREEN]);
	DrawSquare( 1180 , 280 ,110,colors[BLACK]);
	DrawSquare( 1185 , 285 ,100,colors[SLATE_GRAY]);
	DrawSquare( 1020 , 280 ,110,colors[BLACK]);
	DrawSquare( 1025 , 285 ,100,colors[GREEN]);
	DrawSquare( 860 , 280 ,110,colors[BLACK]);
	DrawSquare( 865 , 285 ,100,colors[WHITE]);
	DrawSquare( 1180 , 395 ,110,colors[BLACK]);
	DrawSquare( 1185 , 400 ,100,colors[WHITE]);
	DrawSquare( 1020 , 395 ,110,colors[BLACK]);
	DrawSquare( 1025 , 400 ,100,colors[GREEN]);
	DrawSquare( 860 , 395 ,110,colors[BLACK]);
	DrawSquare( 865 , 400 ,100,colors[WHITE]);
	DrawSquare( 1180 , 510 ,110,colors[BLACK]);
	DrawSquare( 1185 , 515 ,100,colors[WHITE]);
	DrawSquare( 1020 , 510 ,110,colors[BLACK]);
	DrawSquare( 1025 , 515 ,100,colors[GREEN]);
	DrawSquare( 860 , 510 ,110,colors[BLACK]);
	DrawSquare( 865 , 515 ,100,colors[WHITE]);
	DrawSquare( 1180 , 625 ,110,colors[BLACK]);
	DrawSquare( 1185 , 630 ,100,colors[WHITE]);
	DrawSquare( 1020 , 625 ,110,colors[BLACK]);
	DrawSquare( 1025 , 630 ,100,colors[GREEN]);
	DrawSquare( 860 , 625 ,110,colors[BLACK]);
	DrawSquare( 865 , 630 ,100,colors[WHITE]);

 }
 void boardBLUE()
 {
 	DrawSquare( 2000 , 1210 ,110,colors[BLACK]);
 	DrawSquare( 2005 , 1215 ,100,colors[WHITE]);
 	DrawSquare( 2000 , 1030 ,110,colors[BLACK]);
	DrawSquare( 2005 , 1035 ,100,colors[WHITE]);
	DrawSquare( 2000, 850 ,110,colors[BLACK]);
	DrawSquare( 2005 , 855 ,100,colors[WHITE]);
	DrawSquare( 1875 , 1210 ,110,colors[BLACK]);
 	DrawSquare( 1880 , 1215 ,100,colors[WHITE]);
 	DrawSquare( 1875 , 1030 ,110,colors[BLACK]);
	DrawSquare( 1880 , 1035 ,100,colors[BLUE]);
	DrawSquare( 1875, 850 ,110,colors[BLACK]);
	DrawSquare( 1880 , 855 ,100,colors[BLUE]);
	DrawSquare( 1750 , 1210 ,110,colors[BLACK]);
 	DrawSquare( 1755 , 1215 ,100,colors[SLATE_GRAY]);
 	DrawSquare( 1750 , 1030 ,110,colors[BLACK]);
	DrawSquare( 1755 , 1035 ,100,colors[BLUE]);
	DrawSquare( 1750, 850 ,110,colors[BLACK]);
	DrawSquare( 1755 , 855 ,100,colors[WHITE]);
	DrawSquare( 1625 , 1210 ,110,colors[BLACK]);
 	DrawSquare( 1630 , 1215 ,100,colors[WHITE]);
 	DrawSquare( 1625 , 1030 ,110,colors[BLACK]);
	DrawSquare( 1630 , 1035 ,100,colors[BLUE]);
	DrawSquare( 1625, 850 ,110,colors[BLACK]);
	DrawSquare( 1630 , 855 ,100,colors[WHITE]);
	DrawSquare( 1500 , 1210 ,110,colors[BLACK]);
 	DrawSquare( 1505 , 1215 ,100,colors[WHITE]);
 	DrawSquare( 1500 , 1030 ,110,colors[BLACK]);
	DrawSquare( 1505 , 1035 ,100,colors[BLUE]);
	DrawSquare( 1500, 850 ,110,colors[BLACK]);
	DrawSquare( 1505 , 855 ,100,colors[WHITE]);
	DrawSquare( 1375 , 1210 ,110,colors[BLACK]);
 	DrawSquare( 1380 , 1215 ,100,colors[WHITE]);
 	DrawSquare( 1375 , 1030 ,110,colors[BLACK]);
	DrawSquare( 1380 , 1035 ,100,colors[BLUE]);
	DrawSquare( 1375, 850 ,110,colors[BLACK]);
	DrawSquare( 1380 , 855 ,100,colors[WHITE]);

 }
 void boardRED()
 {
 	DrawSquare( 50 , 1210 ,110,colors[BLACK]);
	DrawSquare( 55 , 1215 ,100,colors[WHITE]);
	DrawSquare( 50 , 1030 ,110,colors[BLACK]);
	DrawSquare( 55 , 1035 ,100,colors[WHITE]);
	DrawSquare( 50, 850 ,110,colors[BLACK]);
	DrawSquare( 55 , 855 ,100,colors[WHITE]);
	DrawSquare( 170 , 1210 ,110,colors[BLACK]);
	DrawSquare( 175 , 1215 ,100,colors[RED]);
	DrawSquare( 170 , 1030 ,110,colors[BLACK]);
	DrawSquare( 175 , 1035 ,100,colors[RED]);
	DrawSquare( 170, 850 ,110,colors[BLACK]);
	DrawSquare( 175 , 855 ,100,colors[WHITE]);
	DrawSquare( 290 , 1210 ,110,colors[BLACK]);
	DrawSquare( 295 , 1215 ,100,colors[WHITE]);
	DrawSquare( 290 , 1030 ,110,colors[BLACK]);
	DrawSquare( 295 , 1035 ,100,colors[RED]);
	DrawSquare( 290, 850 ,110,colors[BLACK]);
	DrawSquare( 295 , 855 ,100,colors[SLATE_GRAY]);
	DrawSquare( 410 , 1210 ,110,colors[BLACK]);
	DrawSquare( 415 , 1215 ,100,colors[WHITE]);
	DrawSquare( 410 , 1030 ,110,colors[BLACK]);
	DrawSquare( 415 , 1035 ,100,colors[RED]);
	DrawSquare( 410, 850 ,110,colors[BLACK]);
	DrawSquare( 415 , 855 ,100,colors[WHITE]);
	DrawSquare( 530 , 1210 ,110,colors[BLACK]);
	DrawSquare( 535 , 1215 ,100,colors[WHITE]);
	DrawSquare( 530 , 1030 ,110,colors[BLACK]);
	DrawSquare( 535 , 1035 ,100,colors[RED]);
	DrawSquare( 530, 850 ,110,colors[BLACK]);
	DrawSquare( 535 , 855 ,100,colors[WHITE]);
	DrawSquare( 650 , 1210 ,110,colors[BLACK]);
	DrawSquare( 655 , 1215 ,100,colors[WHITE]);
	DrawSquare( 650 , 1030 ,110,colors[BLACK]);
	DrawSquare( 655 , 1035 ,100,colors[RED]);
	DrawSquare( 650, 850 ,110,colors[BLACK]);
	DrawSquare( 655 , 855 ,100,colors[WHITE]);
	
 }
 
void SetCanvasSize(int width, int height) {
	glMatrixMode (GL_PROJECTION);
	glLoadIdentity();
	glOrtho(0, width, 0, height, -1, 1); // set the screen size to given width and height.
	glMatrixMode (GL_MODELVIEW);
	glLoadIdentity();
}
bool Rpiece[4],Bpiece[4],Gpiece[4],Ypiece[4];
int num;
int p;
void players()
{
	
	
	int Players;
	cout<<"Enter Number Of Players [2-4]\n";
	cin>>Players;
	while (Players<=1 || Players > 4)
	{
		cout<<"Players can only be between 2 and 4\n";
		cout<<"Re-enter Number Of Players \n";
		cin>>Players;

	}
	p=Players;
	const int n = Players ;
	string p[n],pcolor[n];
	int piece[n][4],score[n];
	bool color[4]={false,false,false,false};
	for (int i= 0 ; i < n ; i++ )
	{
		cout<<"Enter Name Of Player "<<(i+1)<<endl;
		cin>>p[i];


	}
	for (int i = 0 ; i < n ; i++ )
	{
		int c;
		cout<<"Player "<<p[i]<<" Select Color From \n\t1. RED\n\t2. BLUE\n\t3. GREEN\n\t4. YELLOW\n";
		cin>>c;
		while (c<1 || c > 4 || color[c]==true)
	{
		if(c<1 || c > 4 )
		{
			cout<<"Please Enter a Valid Color [1-4]\n";
		}
		if(color[c]=true)
		{
			cout<<"Color You Selected Has Already Been Selected \n";
		}

		
		cin>>c;

	}
		switch (c)
		{
			case 1 : 
			{
				pcolor[i]="RED";
				color[c]=true;
				break;
			}
			case 2 : 
			{
				pcolor[i]="BLUE";
				color[c]=true;
				break;
			}
			case 3 : 
			{
				pcolor[i]="GREEN";
				color[c]=true;
				break;
			}
			case 4 : 
			{
				pcolor[i]="DARK_GOLDEN_ROD";
				color[c]=true;
				break;
			}


		}

	}
}

/*
 * Main Canvas drawing function.
 * */
//Board *b;
void Dice(int toss)
{
	
	switch (toss)
	{
		case 1:
		{
		
			DrawRoundRect( 2200 , 50 ,110,120,colors[ANTIQUE_WHITE]); 
			DrawCircle(2258,110,12,colors[RED]);
			break;
		}
		case 2:
		{
			DrawRoundRect( 2200 , 50 ,110,120,colors[ANTIQUE_WHITE]); 
			DrawCircle(2230,145,10,colors[RED]);
			DrawCircle(2285,75,10,colors[RED]);
			
			break;
		}
		case 3:
		{
			DrawRoundRect( 2200 , 50 ,110,120,colors[ANTIQUE_WHITE]); 
			DrawCircle(2230,145,10,colors[RED]);
			DrawCircle(2285,75,10,colors[RED]);
			DrawCircle(2258,110,12,colors[RED]);
			break;
			
		}
		case 4:
		{
			DrawRoundRect( 2200 , 50 ,110,120,colors[ANTIQUE_WHITE]); 
			DrawCircle(2240,135,10,colors[RED]);
			DrawCircle(2275,135,10,colors[RED]);
			DrawCircle(2240,85,10,colors[RED]);
			DrawCircle(2275,85,10,colors[RED]);
			
			
			break;
		}
		case 5:
		{
			DrawRoundRect( 2200 , 50 ,110,120,colors[ANTIQUE_WHITE]); 
			DrawCircle(2230,145,10,colors[RED]);
			DrawCircle(2285,145,10,colors[RED]);
			DrawCircle(2230,75,10,colors[RED]);
			DrawCircle(2285,75,10,colors[RED]);
			DrawCircle(2258,110,12,colors[RED]);
			break;
		}
		case 6:
		{
			DrawRoundRect( 2200 , 50 ,110,120,colors[ANTIQUE_WHITE]); 
			DrawCircle(2240,145,10,colors[RED]);
			DrawCircle(2275,145,10,colors[RED]);
			DrawCircle(2240,110,10,colors[RED]);
			DrawCircle(2275,110,10,colors[RED]);
			DrawCircle(2240,75,10,colors[RED]);
			DrawCircle(2275,75,10,colors[RED]);
	
			break;
		}
	
	}
	
}
void pieceYellow()
{
	if (Ypiece[0]==true)
	{
		DrawCircle(1615,1600,100,colors[DARK_GOLDEN_ROD]);
	
	}
	else
	{
		DrawCircle(1615,1600,100,colors[BLACK]);

	}
	if (Ypiece[1]==true)
	{
		DrawCircle(1965,1600,100,colors[DARK_GOLDEN_ROD]);
	
	}
	else
	{
		DrawCircle(1965,1600,100,colors[BLACK]);

	}
		if (Ypiece[2]==true)
	{
		DrawCircle(1615,1900,100,colors[DARK_GOLDEN_ROD]);
	
	}
	else
	{
		DrawCircle(1615,1900,100,colors[BLACK]);

	}
			if (Ypiece[3]==true)
	{
		DrawCircle(1965,1900,100,colors[DARK_GOLDEN_ROD]);
	
	}
	else
	{
		DrawCircle(1965,1900,100,colors[BLACK]);

	}

}
void pieceBlue()
{
	if (Bpiece[0]==true)
	{
		DrawCircle(1615,250,100,colors[DARK_BLUE]);
	
	}
	else
	{
		DrawCircle(1615,250,100,colors[BLACK]);

	}
	if (Bpiece[1]==true)
	{
		DrawCircle(1965,250,100,colors[DARK_BLUE]);
	
	}
	else
	{
		DrawCircle(1965,250,100,colors[BLACK]);

	}
		if (Bpiece[2]==true)
	{
		DrawCircle(1615,550,100,colors[DARK_BLUE]);
	
	}
	else
	{
		DrawCircle(1615,550,100,colors[BLACK]);

	}
			if (Bpiece[3]==true)
	{
		DrawCircle(1965,550,100,colors[DARK_BLUE]);
	
	}
	else
	{
		DrawCircle(1965,550,100,colors[BLACK]);

	}
	
}
void pieceRed()
{
	if (Rpiece[0]==true)
	{
		DrawCircle(250,1600,100,colors[DARK_RED]);
	
	}
	else
	{
		DrawCircle(250,1600,100,colors[BLACK]);

	}
	if (Rpiece[1]==true)
	{
		DrawCircle(600,1600,100,colors[DARK_RED]);
	
	}
	else
	{
		DrawCircle(600,1600,100,colors[BLACK]);

	}
		if (Rpiece[2]==true)
	{
		DrawCircle(250,1900,100,colors[DARK_RED]);
	
	}
	else
	{
		DrawCircle(250,1900,100,colors[BLACK]);

	}
			if (Rpiece[3]==true)
	{
		DrawCircle(600,1900,100,colors[DARK_RED]);
	
	}
	else
	{
		DrawCircle(600,1900,100,colors[BLACK]);

	}
}
void pieceGreen()
{
	if (Gpiece[0]==true)
	{
		DrawCircle(250,250,100,colors[DARK_GREEN]);
	
	}
	else
	{
		DrawCircle(250,250,100,colors[BLACK]);

	}
	if (Gpiece[1]==true)
	{
		DrawCircle(600,250,100,colors[DARK_GREEN]);
	
	}
	else
	{
		DrawCircle(600,250,100,colors[BLACK]);

	}
		if (Gpiece[2]==true)
	{
		DrawCircle(250,550,100,colors[DARK_GREEN]);
	
	}
	else
	{
		DrawCircle(250,550,100,colors[BLACK]);

	}
			if (Gpiece[3]==true)
	{
		DrawCircle(600,550,100,colors[DARK_GREEN]);
	
	}
	else
	{
		DrawCircle(600,550,100,colors[BLACK]);

	}
	

}
int a=0;
int arr[52][2]={{105,1265},{225,1265},{345,1265},{465,1265},{585,1265},{705,1265},{915,1430},{915,1555},{915,1680},{915,1805},{915,1930},{915,2055},{1075,2055},{1235,2055},{1235,1930},{1235,1805},{1235,1680},{1235,1555},{1235,1430},{1430,1265},{1550,1265},{1770,1265}};
void GameDisplay()/**/{
	// set the background color using function glClearColor.
	// to change the background play with the red, green and blue values below.
	// Note that r, g and b values must be in the range [0,1] where 0 means dim rid and 1 means pure red and so on.
	
	glClearColor(0/*Red Component*/, 0,	//148.0/255/*Green Component*/,
			0.0/*Blue Component*/, 0 /*Alpha component*/); // Red==Green==Blue==1 --> White Colour
	glClear (GL_COLOR_BUFFER_BIT); //Update the colors
	

	DrawSquare( 0 , 0 ,2160,colors[ANTIQUE_WHITE]); 
	DrawSquare( 10 , 10 ,2140,colors[BLACK]);

	DrawRoundRect( 100 , 1450 ,650,650,colors[RED]); 
	DrawCircle(250,1600,100,colors[BLACK]);
	DrawCircle(600,1600,100,colors[BLACK]);
	DrawCircle(250,1900,100,colors[BLACK]);
	DrawCircle(600,1900,100,colors[BLACK]);
	DrawRoundRect( 100 , 100 ,650,650,colors[GREEN]); 
	DrawCircle(250,250,100,colors[BLACK]);
	DrawCircle(600,250,100,colors[BLACK]);
	DrawCircle(250,550,100,colors[BLACK]);
	DrawCircle(600,550,100,colors[BLACK]);
	DrawRoundRect( 1450 , 100 ,650,650,colors[MIDNIGHT_BLUE]); 
	DrawCircle(1615,250,100,colors[BLACK]);
	DrawCircle(1965,250,100,colors[BLACK]);
	DrawCircle(1615,550,100,colors[BLACK]);
	DrawCircle(1965,550,100,colors[BLACK]);
	DrawRoundRect( 1450 , 1450 ,650,650,colors[GOLD]); 
	DrawCircle(1615,1600,100,colors[BLACK]);
	DrawCircle(1965,1600,100,colors[BLACK]);
	DrawCircle(1615,1900,100,colors[BLACK]);
	DrawCircle(1965,1900,100,colors[BLACK]);
    if(pcolor[0]=="YELLOW"||pcolor[1]=="YELLOW"||pcolor[2]=="YELLOW"||pcolor[3]=="YELLOW")
    	Ypiece[0]=Ypiece[1]=Ypiece[2]=Ypiece[3]=true;
    	pieceYellow();
    if(pcolor[0]=="GREEN"||pcolor[1]=="GREEN"||pcolor[2]=="GREEN"||pcolor[3]=="GREEN")
    	Gpiece[0]=Gpiece[1]=Gpiece[2]=Gpiece[3]=true;
    pieceGreen();

	if(pcolor[0]=="RED"||pcolor[1]=="RED"||pcolor[2]=="RED"||pcolor[3]=="RED")
    Rpiece[0]=Rpiece[1]=Rpiece[2]=Rpiece[3]=true;
    pieceRed();
	if(pcolor[0]=="BLUE"||pcolor[1]=="BLUE"||pcolor[2]=="BLUE"||pcolor[3]=="BLUE")
    Bpiece[0]=Bpiece[1]=Bpiece[2]=Bpiece[3]=true;
    pieceBlue();
	DrawTriangle( 800, 780 , 1080, 1040 , 1340 , 780, colors[GREEN] );
	DrawTriangle( 1340, 780 , 1120, 1080 , 1340 , 1340, colors[DARK_BLUE] );
	DrawTriangle( 1340, 1340 , 1080, 1120 , 800 , 1340, colors[DARK_GOLDEN_ROD] );
	DrawTriangle( 800, 780 , 1040, 1080 , 800 , 1340, colors[RED] );
	boardGREEN();
	boardRED();
	boardBLUE();
	boardYELLOW();
	DrawString(2200,2000,"Press space to roll dice",colors[WHITE]);
	DrawCircle(arr[a][0],arr[a][1],50,colors[RED]);
	a++;
	
	DrawCircle(arr[20][0],arr[20][1],50,colors[BLUE]);
	
	for(int i = 0 ; i < 4 ; i++ )
	{
		
			num=roll();
			Dice(num);
			if (pcolor[i]=="RED")
			DrawCircle(arr[num][0],arr[num][1],50,colors[RED]);
			else if (pcolor[i]=="GREEN")
			DrawCircle(arr[num][0],arr[num][1],50,colors[GREEN]);
			else if (pcolor[i]=="BLUE")
			DrawCircle(arr[num][0],arr[num][1],50,colors[BLUE]);
			else if (pcolor[i]=="YELLOW")
			DrawCircle(arr[num][0],arr[num][1],50,colors[DARK_GOLDEN_ROD]);
			
		
	
	}
	
	
	glutSwapBuffers(); // do not modify this line..

}

/*This function is called (automatically) whenever any non-printable key (such as up-arrow, down-arraw)
 * is pressed from the keyboard
 *
 * You will have to add the necessary code here when the arrow keys are pressed or any other key is pressed...
 *
 * This function has three argument variable key contains the ASCII of the key pressed, while x and y tells the
 * program coordinates of mouse pointer when key was pressed.
 *
 * */

void NonPrintableKeys(int key, int x, int y) {
	if (key
			== GLUT_KEY_LEFT /*GLUT_KEY_LEFT is constant and contains ASCII for left arrow key*/) {
		// what to do when left key is pressed...

	} else if (key
			== GLUT_KEY_RIGHT /*GLUT_KEY_RIGHT is constant and contains ASCII for right arrow key*/) {

	} else if (key
			== GLUT_KEY_UP/*GLUT_KEY_UP is constant and contains ASCII for up arrow key*/) {

	}

	else if (key
			== GLUT_KEY_DOWN/*GLUT_KEY_DOWN is constant and contains ASCII for down arrow key*/) {

	}
	if (key == ' ' || key == 32/* Spacebar Key*/)
	{
		num=roll();
		
	}
	/* This function calls the Display function to redo the drawing. Whenever you need to redraw just call
	 * this function*/

	glutPostRedisplay();

}

/*This function is called (automatically) whenever any printable key (such as x,b, enter, etc.)
 * is pressed from the keyboard
 * This function has three argument variable key contains the ASCII of the key pressed, while x and y tells the
 * program coordinates of mouse pointer when key was pressed.
 * */
void PrintableKeys(unsigned char key, int x, int y) {
	if (key == 27/* Escape key ASCII*/) {
		exit(1); // exit the program when escape key is pressed.
	}

	if (key == 'b' || key == 'B') //Key for placing the bomb
			{
		//do something if b is pressed
		cout << "b pressed" << endl;

	}
	
	glutPostRedisplay();
}

/*
 * This function is called after every 1000.0/FPS milliseconds
 * (FPS is defined on in the beginning).
 * You can use this function to animate objects and control the
 * speed of different moving objects by varying the constant FPS.
 *
 * */
void Timer(int m) {

	// implement your functionality here

	// once again we tell the library to call our Timer function after next 1000/FPS
	glutTimerFunc(1000.0, Timer, 0);
}

/*This function is called (automatically) whenever your mouse moves witin inside the game window
 *
 * You will have to add the necessary code here for finding the direction of shooting
 *
 * This function has two arguments: x & y that tells the coordinate of current position of move mouse
 *
 * */

void MousePressedAndMoved(int x, int y) {
	cout << x << " " << y << endl;
	glutPostRedisplay();
}
void MouseMoved(int x, int y) {

	glutPostRedisplay();
}

/*This function is called (automatically) whenever your mouse button is clicked witin inside the game window
 *
 * You will have to add the necessary code here for shooting, etc.
 *
 * This function has four arguments: button (Left, Middle or Right), state (button is pressed or released),
 * x & y that tells the coordinate of current position of move mouse
 *
 * */
void MouseClicked(int button, int state, int x, int y) {

	if (button == GLUT_LEFT_BUTTON) // dealing only with left button
			{
		cout << GLUT_DOWN << " " << GLUT_UP << endl;

	} else if (button == GLUT_RIGHT_BUTTON) // dealing with right button
			{

	}
	glutPostRedisplay();
}


/*
 * our gateway main function
 * */
int main(int argc, char*argv[]) {
	
	//b = new Board(60, 60); // create a new board object to use in the Display Function ...

	int width = 3840, height = 2160; // i have set my window size to be 800 x 600
	//b->InitalizeBoard(width, height);
	InitRandomizer(); // seed the random number generator...
	glutInit(&argc, argv); // initialize the graphics library...
	glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGBA); // we will be using color display mode
	glutInitWindowPosition(100, 50); // set the initial position of our window
	glutInitWindowSize(width, height); // set the size of our window
	glutCreateWindow("LUDO"); // set the title of our game window
	SetCanvasSize(width, height); // set the number of pixels...
	int c=0;
	c++;
	
	if (c==1)
	{
		DrawString( 2200, 2100, "open terminal for initial inputs", colors[MISTY_ROSE]);
		players();
	}
	glutDisplayFunc(GameDisplay); // tell library which function to call for drawing Canvas.
	//if (c=1)
	//{
	//	DrawString( 2200, 2100, "Open terminal for inputs", colors[MISTY_ROSE]);
	//	players();
	//}
	
	// Register your functions to the library,
	// you are telling the library names of function to call for different tasks.
	//glutDisplayFunc(display); // tell library which function to call for drawing Canvas.

	glutDisplayFunc(GameDisplay); // tell library which function to call for drawing Canvas.
	glutSpecialFunc(NonPrintableKeys); // tell library which function to call for non-printable ASCII characters
	glutKeyboardFunc(PrintableKeys); // tell library which function to call for printable ASCII characters
	// This function tells the library to call our Timer function after 1000.0/FPS milliseconds...
	glutTimerFunc(1000.0, Timer, 0);

	glutMouseFunc(MouseClicked);
	glutPassiveMotionFunc(MouseMoved); // Mouse
	glutMotionFunc(MousePressedAndMoved); // Mouse

	// now handle the control to library and it will call our registered functions when
	// it deems necessary...
	glutMainLoop();
	return 1;
}
#endif /* AsteroidS_CPP_ */
