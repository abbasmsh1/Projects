#include "Superior.h"  
	
Superior::Superior()
{
	setPrice(1000);
    setReserved(false);
}
	
Superior::~Superior()
{
	cout<<"Superior room was blown off the face of the earth\n";
}