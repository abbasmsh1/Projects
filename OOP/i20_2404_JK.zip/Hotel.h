#include "Customer.cpp"
#include "Floor.cpp"
#include <fstream>
#include <iostream>
#include <ctime>
#include<bits/stdc++.h>
class Hotel  
{
	private:
		Floor f[5];
		Customer cust[250];
		fstream file;
		fstream c;
		int customers;
	public:

		Hotel();
		void menu();
		void checkin();
		void reserve(int , int);
		void checkReserved();
		void DetailedReport();
		void save();
		void NewCust();
		void setRoom(int);
		bool checkCustomer(string);
		~Hotel();

};