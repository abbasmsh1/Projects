#include "Floor.h"  
	
Floor::Floor()
{
	for(int i = 0 ; i < 10 ; i++)
    {
        S[i].setRoomNo(i);
    }
    for(int i = 10 ; i < 20 ; i++)
    {
        M[i-10].setRoomNo(i);
    }
    for(int i = 20 ; i < 30 ; i++)
    {
        Su[i-20].setRoomNo(i);
    }
    for(int i = 30 ; i < 40 ; i++)
    {
        J[i-30].setRoomNo(i);
    }
    for(int i = 40 ; i < 50 ; i++)
    {
        St[i-40].setRoomNo(i);
    }
}
Standard* Floor :: getStandard()
{
    return S;
}
moderate* Floor :: getmoderate()
{
    return M;
}
Superior* Floor :: getSuperior()
{
    return Su;
}
JuniorSuite* Floor :: getJuniorSuite()
{
    return J;
}
Suite* Floor :: getSuite()
{
    return St;
}
Floor::~Floor()
{
	cout<<"floor submerged\n";
}