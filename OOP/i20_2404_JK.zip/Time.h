#include <iostream>
#include <ctime>
using namespace std;
	
class Time  
{
	private:
		int Year;
		int Month;
		int Day;
		int Hour;
		
	public:

		Time();
		void setYear(int);
		void setMonth(int);
		void setDay(int);
		void setTime();
		int getYear();
		int getMonth();
		int getDay();
		void Display();
		Time& operator-(Time T);
		Time& operator+(int n);
		Time& operator = (Time T);
		bool operator==(Time C);
		void operator=(tm *C);
		~Time();

};
