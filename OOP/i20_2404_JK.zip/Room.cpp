#include "Room.h"
Room::Room()
{
	RoomNo = NULL;
	Price=NULL;
	Reserved=false;

}
void Room :: setRoomNo(int R)
{
	RoomNo=R;
}
void Room :: setPrice(int P)
{
	Price = P;
}
void Room :: setReserved(bool R)
{
	Reserved=R;
}
void Room :: Display()
{
	cout<<"RoomNo: "<<RoomNo<<endl;
	cout<<"Price: "<<Price<<endl;
	cout<<"Reserved: "<< (Reserved ? "yes ":"No")<<endl;
}
int Room:: getRoomNo()
{
	return RoomNo;
}
int Room:: getPrice()
{
	return Price;
}
bool Room :: getReserved()
{
	return Reserved;
}

void Room:: operator=(Room R)
{
	Price=R.Price;
	RoomNo=R.RoomNo;
	Reserved=R.Reserved;
}
Room::~Room()
{
	cout<<"Room Destroyed\n";
}
