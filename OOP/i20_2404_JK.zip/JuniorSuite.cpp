#include "JuniorSuite.h"  
	
JuniorSuite::JuniorSuite()
{
	setPrice(2000);
    setReserved(false);
}
	
JuniorSuite::~JuniorSuite()
{
	cout<<"Junior suite was destroyed by feminists in the aurat march\n";
}