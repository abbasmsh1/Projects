#include "Hotel.h"  

Hotel::Hotel()
{
    file.open("Rooms.dat", ios :: binary | ios :: out );
    
       char* x = reinterpret_cast<char*>(this);
       file.read(x,sizeof(this));
       
    customers=1;
   file.close();
    c.open("customers.txt", ios :: in | ios :: out);
    
        x = reinterpret_cast<char*>(cust);
       c.read(x,sizeof(Customer));
   
    c.close();
  
   
    

}
void Hotel:: menu()
{
    cout<<"\t\tHotel Management System\t\t\n";
    cout<<"1.\tPress 1 to Reserve a Room\n";
    cout<<"2.\tPress 2 to Checkin a Customer / Visitor\n";
    cout<<"3.\tPress 3 to View Reserved Rooms\n";
    cout<<"4.\tPress 4 to view Detailed Report\n";
    cout<<"5.\tPress 5 to Exit\n";
    int choice ;
    cin>> choice;
    switch (choice)
    {
        case 1 : 
        {
            int choice;
            cout<<"Are you new to our hotel or have you experienced our services before?\nfor new Customer press 1.\nElse press 2.\n";
            cin>>choice;
            int n;
           switch ( choice)
           {
               case 1:
               {
                    /* NewCust(); */
                    n=customers-1;
                    cust[n].initCustomer();
                    cout<<endl<<endl<<endl;
                    checkReserved();
                    setRoom(n);
                    if(cust[n].getRoomNo()<10)
                    {
                        cust[n].setBalance(300*cust[n].getDays());
                    }
                    else if(cust[n].getRoomNo()<20)
                    {
                        cust[n].setBalance(500*cust[n].getDays());
                    }
                    else if(cust[n].getRoomNo()<30)
                    {
                        cust[n].setBalance(800*cust[n].getDays());
                    }
                    else if(cust[n].getRoomNo()<40)
                    {
                        cust[n].setBalance(2000*cust[n].getDays());
                    }
                    else if(cust[n].getRoomNo()<50)
                    {
                        cust[n].setBalance(5000*cust[n].getDays());
                    }
                    break;
               }
               case 2:
               {
                   string fname,lname,fullName;
                   bool flag=false;
                   int i =0;
                   cout<<"Enter First Name\n";
                   cin>>fname;
                   cout<<"Enter Last Name\n";
                   cin>>lname;
                   fullName=fname+lname;
                   for( i = 0 ; i < customers ; i++)
                   {
                       if(cust[i].getFullName()==fullName)
                       {
                            flag=true;
                            break;
                       }
                   }
                   n=i;
                   if(flag)
                   {
                       setRoom(n);
                       if(cust[n].getRoomNo()<10)
                    {
                        cust[n].setBalance(300*cust[n].getDays());
                    }
                    else if(cust[n].getRoomNo()<20)
                    {
                        cust[n].setBalance(500*cust[n].getDays());
                    }
                    else if(cust[n].getRoomNo()<30)
                    {
                        cust[i].setBalance(800*cust[n].getDays());
                    }
                    else if(cust[n].getRoomNo()<40)
                    {
                        cust[n].setBalance(2000*cust[n].getDays());
                    }
                    else if(cust[n].getRoomNo()<50)
                    {
                        cust[n].setBalance(5000*cust[n].getDays());
                    }
                    break;
                   }
                   
                   
            }
        
        }
           int x;
           
        cout<<"Bill is "<<cust[n].getBalance()<<"\nWould you like to pay now or when you check in?\nTo Pay Now Press 1.\nTo Pay on Checkin Press 2. \n";
        cin>>x;
            if(x==1)
            {
                cust[n].setBalance(0);
            }
            else
            {
                cust[n].setBalance(cust[n].getBalance()*-1);
            }
           
           break;
        }
        case 2 : 
        {
            checkin();
            break;
        }
        case 3: 
        {
            checkReserved();
            break;
        }
        case 4: 
        {
            DetailedReport();
            break;
        }
        case 5:
        {
            save();
            exit(0);
        }
        
    }
    menu();
}
bool Hotel :: checkCustomer(string Fname)
{
    
        int n;
        for(int i = 0 ; i < customers ; i++)
        {
            if(cust[i].getFullName()==Fname)
            {
               return true;
                n=i;
            }
        }
        return false;
}
void Hotel:: checkin()
{
    int n;
    cout<<"Have you already reserved a room? \nIf Yes press 1.\nFor New Checkin press 2\n";
    cin>>n;
    if(n=1)
    {   
        string firstName,lastName,Fname;
        cout<<"Please Enter Your First Name\n";
        cin>>firstName;
        cout<<"PLease Enter Your Last Name\n";
        cin>>lastName;
        Fname=firstName+lastName;
        int i;
        string fullName;
        bool flag;
        for( i = 0 ; i < customers ; i++)
                   {
                       if(cust[i].getFullName()==fullName)
                       {
                            flag=true;
                            break;
                       }
                   }
        if (flag)
        {
            time_t currentTime(NULL);
            struct tm* timeinfo;
            time(&currentTime); 
            timeinfo = localtime(&currentTime);
            cust[i].setCheckin(timeinfo);
            cust[i].setCheckout(timeinfo+cust[i].getDays());
            if(cust[i].getBalance()>0)
            {
                cout<<"Your Remaining Balance is ";
                cust[i].getBalance();
            }
        }
        
        else
        {
            cout<<"Sorry you don't exist in our data base\nplease reserve a room or checkin\n";
        }
    }
    else
    {
        NewCust();
        setRoom(customers-1);
        n=customers-1;
        if(cust[n].getRoomNo()<10)
        {
            cust[n].setBalance(300*cust[n].getDays());
        }
        else if(cust[n].getRoomNo()<20)
        {
            cust[n].setBalance(500*cust[n].getDays());
        }
        else if(cust[n].getRoomNo()<30)
        {
            cust[n].setBalance(800*cust[n].getDays());
        }
        else if(cust[n].getRoomNo()<40)
        {
        cust[n].setBalance(2000*cust[n].getDays());
        }
        else if(cust[n].getRoomNo()<50)
        {
            cust[n].setBalance(5000*cust[n].getDays());
        }

        
    }
}
void Hotel :: setRoom(int c)
{
    int RoomNo,Floor;
        checkReserved();
        cout<<"Select Available Room Number\n";
        cout<<"Enter Room Number\n";
        cin>>RoomNo;
        cout<<"Enter Floor No.\n";
        cin>>Floor;
        cust[c].setRoomNo(RoomNo);
        cust[c].setFloorNo(Floor);
        reserve(Floor,RoomNo);
}
void Hotel :: NewCust()
{
    customers++;
    cust[customers].initCustomer();
}
void Hotel :: reserve(int floor ,int room)
{
    if(room < 10)
    {
        f[floor].getStandard()[room].setReserved(true);
    }
    else  if(room < 20)
    {
        f[floor].getmoderate()[room-10].setReserved(true);
    }
    else  if(room < 30)
    {
        f[floor].getSuperior()[room-20].setReserved(true);
    }
    else if(room < 40)
    {
        f[floor].getJuniorSuite()[room-30].setReserved(true);
    }
    else
    {
        f[floor].getSuite()[room-40].setReserved(true);
    }

}
void Hotel :: checkReserved()
{
    for(int i = 0 ; i < 5 ; i++)
    {
        cout<<"Floor "<<i;
        cout<<endl<<endl<<"Standard Rooms"<<endl<<"||";
        for(int j = 0 ; j < 10 ; j++)
        {
            cout<<"  Room No."<<f[i].getStandard()[j].getRoomNo()<<"   ->";
            cout<<"||  "<<(f[i].getStandard()[j].getReserved()? "Reserved" : "Available") <<" ||";
        }
        cout<<endl<<endl<<"Moderate Rooms"<<endl<<"||";
        for(int j = 0 ; j < 10 ; j++)
        {
            cout<<"   Room No."<<f[i].getmoderate()[j].getRoomNo()<<"   ->";
            cout<<"|| "<<(f[i].getmoderate()[j].getReserved()? "Reserved" : "Available")<<" ||";
        }
        cout<<endl<<endl<<"Superior Rooms"<<endl<<"||";
        for(int j = 0 ; j < 10 ; j++)
        {
            cout<<"    Room No."<<f[i].getSuperior()[j].getRoomNo()<<"   ->";
            cout<<"|| "<<(f[i].getSuperior()[j].getReserved()? "Reserved" : "Available")<<" ||";
        
        }
        cout<<endl<<endl<<"Junior Suites"<<endl<<"||";
        for(int j = 0 ; j < 10 ; j++)
        {
            cout<<"    Room No."<<f[i].getJuniorSuite()[j].getRoomNo()<<"   ->";
            cout<<"|| "<<(f[i].getJuniorSuite()[j].getReserved()? "Reserved" : "Available")<<" ||";
        
        }
        cout<<endl<<endl<<"Suites"<<endl<<"||";
        for(int j = 0 ; j < 10 ; j++)
        {
            cout<<"    Room No."<<f[i].getSuite()[j].getRoomNo()<<"   ->";
            cout<<"|| "<<(f[i].getSuite()[j].getReserved()? "Reserved" : "Available")<<" ||";
        
        }
         cout<<endl<<endl;
        
       
    }
}
void Hotel :: DetailedReport()
{
    time_t currentTime;
    struct tm* timeinfo;
    time(&currentTime);
    timeinfo = localtime(&currentTime);
    Time C ;
    C =  timeinfo;
    int c=0,o=0;
    for(int i = 0 ; i < customers ; i++)
    {
        if(cust->getCheckin() == C)
        {
            c++;
        }
        if(cust->getCheckout() == C)
        {
            o++;
        }

    }
    int r[5]={0,0,0,0,0};
    for(int i = 0 ; i <5 ; i++)
    {
        for(int j = 0 ; j < 10 ; j++)
        {
            if(f[i].getStandard()[j].getReserved())
            r[0]++;
            if(f[i].getmoderate()[j].getReserved())
            r[1]++;
            if(f[i].getSuperior()[j].getReserved())
            r[2]++;
            if(f[i].getJuniorSuite()[j].getReserved())
            r[3]++;
            if(f[i].getSuite()[j].getReserved())
            r[4]++;

        }
        
    }
    cout<<endl<<endl<<"Number of checkins today : "<<c<<endl;
    cout<<"Number of checkouts today : "<<o<<endl;
    cout<<"Number of reserved rooms today : "<<endl;
    cout<<"\tStandard Rooms  : "<<r[0]<<endl;
    cout<<"\tModerate Rooms  : "<<r[1]<<endl;
    cout<<"\tSuperior Rooms  : "<<r[2]<<endl;
    cout<<"\tJunior Suites   : "<<r[3]<<endl;
    cout<<"\tSuites          : "<<r[4]<<endl;
    cout<<"Number of open rooms today : "<<endl;
    cout<<"\tStandard Rooms  : "<<(50-r[0])<<endl;
    cout<<"\tModerate Rooms  : "<<(50-r[1])<<endl;
    cout<<"\tSuperior Rooms  : "<<(50-r[2])<<endl;
    cout<<"\tJunior Suites   : "<<(50-r[3])<<endl;
    cout<<"\tSuites          : "<<(50-r[4])<<endl;
}
Hotel::~Hotel()
{
	/* delete [] cust; */
}
void Hotel :: save()
{
    file.open("Rooms.dat", ios :: binary | ios :: in );
    
      
    char* x = reinterpret_cast<char*>(this);
    file.write(x,sizeof(this));
    cout<<"Pointer to Rooms "<<x<<endl;
    file.close();
    x = reinterpret_cast<char*>(&cust);
    c.write(x,sizeof(&cust));
    cout<<"Pointer to Customers "<<x<<endl;
    c.close();

}
int main()
{
    Hotel H;
    H.menu();
    return 0;
}