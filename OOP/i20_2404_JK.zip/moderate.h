
#include "Room.h"
	
class moderate  : public Room 
{
	private:

	public:

		moderate();
		~moderate();

};