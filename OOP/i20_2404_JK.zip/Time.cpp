#include "Time.h"  
	
Time :: Time()
{
	Year = 2021;
    Month = 1;
    Day = 1;
    

}
void Time :: setYear(int y)
{
    Year = y;
}
void Time :: setMonth(int m)
{
    Month = m;
}
void Time :: setDay(int D)
{
    Day = D;
}

void Time :: setTime()
{
     int x;
     cout<<"Input Year\n";
     cin>>x;
     setYear(x);
     cout<<"Input Month\n";
     cin>>x;
     setMonth(x);
     cout<<"Input Day\n";
     cin>>x;
     setDay(x);
     
     
     
}
int Time :: getYear()
{
    return Year;
}
int Time :: getMonth()
{
    return Month;
}
int Time :: getDay()
{
    return Day;
}

void Time :: Display()
{
    cout<<Day<<"/"<<Month<<"/"<<Year<<"\t"<<endl;
}
Time& Time:: operator-(Time T)
{
    Time temp;
    temp.Day=Day-T.Day;
    temp.Month=Month-T.Month;
    temp.Year=Year-T.Year;
    return temp;

}
Time& Time:: operator+(int T)
{
    Time temp;
    temp.Day=Day+T;
    temp.Month=Month+T;
    temp.Year=Year+T;
    return temp;

}
Time& Time :: operator=(Time T)
{
    Year=T.Year;
    Month = T.Month;
    Day=T.Day;
    return *this;


}
bool Time ::operator==(Time C)
{
    if (Year == C.Year || Month == C.Month || Day == C.Day)
			{
				return true;
			}
			else 
			{
				return false;
			}
}
void Time ::operator=(tm *C)
{
    Year=C->tm_year;
    Month=C->tm_mon;
    Day=C->tm_mday;
    Hour=C->tm_hour;
}

Time :: ~Time()
{
	cout<<"Time Destroyed\n";
}