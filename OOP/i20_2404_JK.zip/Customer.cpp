#include "Customer.h"  
	
Customer::Customer()
{
	FirstName="";
    LastName="";
    FullName=FirstName+LastName;
    age = NULL;
    gender='\n';
    ID=0;
    Days=NULL;
    floorNo=NULL;
}
void Customer:: setFirstName(string fn)
{
    FirstName=fn;
}
void Customer:: setLastName(string ln)
{
    LastName=ln;
}
void Customer:: setFullName()
{
    FullName=FirstName+LastName;
}
void Customer:: setAge(int a)
{
    age = a;
}
void Customer:: setGender(char g)
{
    gender=g;
}
void Customer:: setID(long int i)
{
    ID = i;
}    
void Customer:: setBalance(double b)
{
    Balance=b;
}
void Customer:: setDays(int d)
{
    Days=d;
}
void Customer:: setFloorNo(int f)
{
        floorNo=f;
}
void Customer :: setRoomNo(int r)
{
    RoomNo=r;
}
void Customer:: setCheckin(tm* c)
{
    checkin.setYear(c->tm_year);
    checkin.setDay(c->tm_mday);
    checkin.setMonth(c->tm_mon);
    
}
void Customer:: setCheckin(Time c)
{
    checkin.setYear(c.getYear());
    checkin.setDay(c.getDay());
    checkin.setMonth(c.getMonth());
    
}
void Customer:: setCheckout(tm* c)
{
    checkout.setYear(c->tm_year);
    checkout.setDay(c->tm_mday);
    checkout.setMonth(c->tm_mon);
}
void Customer:: setCheckout(Time c)
{
    checkout.setYear(c.getYear());
    checkout.setDay(c.getDay());
    checkout.setMonth(c.getMonth());
    
}
void Customer:: setRemaining()
{
    Time R=checkout-checkin;
    Remaining=(R.getDay()*24)+(R.getMonth()*30*24)+(R.getYear()*24*30*12);
}
string Customer:: getFirstName()
{
    return FirstName;
}
string Customer:: getLastName()
{
    return LastName;
}
string Customer:: getFullName()
{
    return FullName;
}
int Customer:: getAge()
{
    return age;
}
char Customer:: getGender()
{
    return gender;
}
int Customer:: getID()
{
    return ID;
}
double Customer:: getBalance()
{
    return Balance;
}
int Customer:: getDays()
{
    return Days;
}
int Customer:: getFloorNo()
{
    return floorNo;
}
int Customer:: getRoomNo()
{
    
    return RoomNo;
}
Time Customer:: getCheckin()
{
    return checkin;
}
Time Customer:: getCheckout()
{
    return checkout;
}
int Customer:: getRemaining()
{
    return Remaining;
}
void Customer :: initCustomer()
{
    string name;
    cout<<"Enter First Name\n";
    cin>>name;
    setFirstName(name);
    cout<<"Enter Last Name\n";
    cin>>name;
    setLastName(name);
    setFullName();
    int x;
    cout<<"enter age\n";
    cin>>x;
    setAge(x);
    cout<<"Enter Gender [For male press M for female press F ]\n";
    cin>>gender;
    cout<<"Enter your ID card Number\n";
    cin>>x;
    setID(x);
    time_t currentTime(NULL);
    struct tm* timeinfo;
    time(&currentTime); 
    timeinfo = localtime(&currentTime);
    setCheckin(timeinfo);
    cout<<"Enter Number of Days you wish to stay\n";
    cin>>x;
    setDays(x);
    setCheckout((timeinfo+x));

    
}
void Customer :: setRoom(int Room)
{
    RoomNo=Room;
}
Customer::~Customer()
{
	cout<<"customer was killed by walkers\n";
}
