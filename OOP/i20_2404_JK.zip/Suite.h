#include "Room.h"
	
class Suite  : public Room
{
	private:

	public:

		Suite();
		~Suite();

};