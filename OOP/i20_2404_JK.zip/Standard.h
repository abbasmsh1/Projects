
#include "Room.cpp"
	
class Standard : public Room  
{
	private: 

	public:

		Standard();
		~Standard();

};