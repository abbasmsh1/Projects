#ifndef Room_h
#define Room_h
#include <iostream>




using namespace std;
class Room  
{
	private:
			int RoomNo;
    		int Price;
			bool Reserved;
	public:

		Room();
		void setRoomNo(int);
		void setPrice(int);
		void setReserved(bool);
		int getRoomNo();
		int getPrice();
		bool getReserved();
		void Display();
		void operator= (Room R);
		virtual ~Room();

};
#endif 