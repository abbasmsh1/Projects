#include "moderate.h"  
	
moderate::moderate()
{
	setPrice(500);
    setReserved(false);
}
	
moderate::~moderate()
{
	cout<<"Moderate Room was occupied by the taliban\n";
}