#include <iostream>
#include <string>
#include <fstream>

using namespace std;

class Customer
{
 protected:
	char* name;
	int age;
	int gender;
	long long id_card;
	int balance;
	int res_days;
	int Floor_no;
	int room_no;
	int room_ty;
	int category;
	int check_in_day;
	int check_in_month;
	int check_in_year;
	int check_out_day;
	int check_out_month;
	int check_out_year;
	int getroom_ty();

	public:
	Customer()
	{

	 age = 0;
	 gender = 0;
	 id_card = 0;
	 balance = 0;
	 res_days = 0;
	 Floor_no = 0;
	 room_no = 0;
	 room_ty = 0;
	 category = 0;
	 check_in_day = 0;
	 check_in_month = 0;
	 check_in_year = 0;
	 check_out_day = 0;
	 check_out_month = 0;
	 check_out_year = 0;

	}
	Customer(char* nm,int ag,int gen,int id,int bal,int res,int Flono,int roty,int rono,int cat,int chinday,int chinmonth,int chinyear,int choutday,int choutmonth,int choutyear)
	{
		name = nm;
		age = ag;
		gender = gen;
		id_card = id;
		balance = bal;
		res_days = res;
		Floor_no = Flono;
		room_no = rono;
		room_ty=roty;
		category = cat;
		check_in_day = chinday;
		check_in_month = chinmonth;
		check_in_year = chinyear;
		check_out_day = choutday;
		check_out_month = choutmonth;
		check_out_year = choutyear;
	}
	
    void setage(int ag)
    {
        age=ag;
    }
	void setname(string nm)
	{
		int len=0;
		for(int i=0;nm[i]!='\0';++i)
		{
			len++;
		}
	this-> name=new char[len];
		for(int i=0;nm[i]!='\0';++i)
		{
			len++;
			name[i]=nm[i];
		}
	}

	void setgender(int gen)
	{
		gender = gen;
	}
	void setid_card(int id)
	{
		id_card = id;
	}
	void setbalance(int bal)
	{
		balance = bal;
	}
	void setres_days(int res)
	{
		res_days = res;
	}
	void setFloor_no(int Flono)
	{
		Floor_no = Flono;
	}
	void setroom_ty(int roty)
	{
		room_ty = roty;
	}
	void setroom_no(int rono)
	{
		room_no = rono;
	}
	void setcategory(int cat)
	{
		category = cat;
	}
	void setcheck_in_day(int chinday)
	{
		check_in_day = chinday;
	}
	void setcheck_in_month(int chinmonth)
	{
		check_in_month = chinmonth;
	}
	void setcheck_in_year(int chinyear)
	{
		check_in_year = chinyear;
	}
	void setcheck_out_day(int choutday)
	{
		check_out_day = choutday;
	}
	void setcheck_out_month(int choutmonth)
	{
		check_out_month = choutmonth;
	}
	void setcheck_out_year(int choutyear)
	{
		check_out_year = choutyear;
	}

int getage()
{
    return age;
    }
	string getname()
	{
		return name;
	}
	int getgender()
	{
	   return gender;
	}
	long long getid_card()
	{
	   return id_card;
	}
	int getbalance()
	{
	   return balance;
	}
	int getres_days()
	{
		return res_days;
	}
	int getFloor_no()
	{
	   return Floor_no;
	}
	int Customer:: getroom_ty()
	{
		return this->room_ty;
	}
	int getroom_no()
	{
		return room_no;
	}
	int getcategory()
	{
	   return category;
	}
	int getcheck_in_day()
	{
	   return check_in_day;
	}
	int getcheck_in_month()
	{
		return check_in_month;
	}
	int getcheck_in_year(int chinyear)
	{
	   return check_in_year = chinyear;
	}
	int getcheck_out_day()
	{
		return check_out_day;
	}
	int getcheck_out_month()
	{
		return check_out_month;
	}
	int getcheck_out_year()
	{
		return check_out_year;
	}
 void  setalval()
 {
		cout << "Enter Name" << endl;
		string name;
cin>>name;
		setname(name);		
		cout << "Enter age of customer: ";
		cin>>this->age;


		cout << "Enter gender: ";
		cin>>this->gender;
		
		cout << "Enter CNIC: ";
		cin>>this->id_card;


		cout << "Enter number of days: ";
		cin>>this->res_days;

		cout << "Enter room type: ";
		cout << "Enter 1 For Standard: ";
		cout << "Enter 2 For Moderate: ";	
		cout << "Enter 3 For Superior: ";
		cout << "Enter 4 For Junior Suite: ";
		cout << "Enter 5 For Suite: ";
		cin>>room_ty;


 }
};
class Check_in
	{
	int check_in_day;
	int check_in_month;
	int check_in_year;
	int check_out_day;
	int check_out_month;
	int check_out_year;

	};
class Room
    {
        protected: 
        int room_ty;
        int room_price;
        bool avalible;
        bool reserved;
        public:
        void setroom_ty(int rt)
        {
            room_ty=rt;
        }
        void setroom_price(int pr)
        {
            room_price=pr;
        }
        void setavalible(int ava)
        {
            avalible=ava;
        }
        void setreserved(int res)
        {
            reserved=res;
        }
        int getroom_ty()
        {
            return room_ty;
        }
        int getroom_price()
        {
            return room_price;
        }
        bool getavalible()
        {
            return avalible;
        }
        bool getreserved()
        {
            return reserved;
        }
    };
class Standard : public Room
{

public:
	Standard()
	    {
	    	cout << "Default Consturtor ";
	    	room_price = 300;
	    }
		~Standard()
	        {
	        	cout << "Standard Destroyed";
	        }
};
class Moderate:public Room
{
public:

	Moderate()
	    {
	    	cout << "Default Consturtor ";
	    	room_price = 500;
    	}
	~Moderate()
	        {
	        	cout << "Standard Destroyed";
	        }

};
class Superior:public Room

{
public:

	Superior()
	{
		cout << "Default Consturtor ";
		room_price = 1000;

	}
		~Superior()
	{
		cout << "Standard Destroyed";
	}

};
class Junior_Suite:protected Room
{
public:

	Junior_Suite()
	{
		cout << "Default Consturtor ";
		room_price = 2000;

	}
		~Junior_Suite()
	{
		cout << "Standard Destroyed";
	}

};
class Suite:public Room

	{
public:

		Suite()
		{
			cout << "Default Consturtor ";
			room_price = 5000;
		}
			~Suite()
		{
			cout << "Standard Destroyed";
		}
	};
	void Main_Menu()
{
	system("cls");
	cout << "\n\t\t\t\t***";
	cout << "\n\t\t\t\t SIMPLE HOTEL MANAGEMENT ";
	cout << "\n\t\t\t\t      * MAIN MENU *";
	cout << "\n\t\t\t\t***";
	cout << "\n\n\n\t\t\t1.Book A Room";
	cout << "\n\t\t\t2.Customer Records";
	cout << "\n\t\t\t3.Rooms Allotted";
	cout << "\n\t\t\t4.Edit Record";
	cout << "\n\t\t\t5.Exit";
	cout << "\n\n\t\t\tEnter Your Choice: ";
}
	int main()
	{
		Customer cust[250];
		Standard stand[5][10];
		Moderate mod[5][10];
		Superior sup[5][10];
		Junior_Suite jrsu[5][10];
		Suite suit[5][10];
		int rotype;
		cout << "\n\t\t\t _________";
		cout << "\n\t\t\t|                           |";
		cout << "\n\t\t\t|  HOTEL MANAGEMENT PROJECT |  ";

		cout << "\n\t\t\t|_________|";
		cout << "\n\n\t\tDeveloped By:";
		cout << "\t Syed Zulfiqar Haider Zaidi";
		cout << "\n\n\n\n\t\t\t\t\tPress any key to continue....!!";
		int choice;
int i=0;
		do
		{
			Main_Menu();
			cin >> choice;
			switch(choice)
			{
				case(1):
                    cust[i].setalval();
					rotype= getroom_ty();
                    break;				
				case(2):
				case(3):
				case(4):
				case(5):
				return 0;
				break;
			}
i++;
		} while (choice < 1 || choice>5);

			cout << "Enter Your Name";

		return 0;

	}