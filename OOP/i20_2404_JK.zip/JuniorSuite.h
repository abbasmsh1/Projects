#include "Room.h"
class JuniorSuite : public Room  
{
	private:
		
	public:

		JuniorSuite();
		~JuniorSuite();

};