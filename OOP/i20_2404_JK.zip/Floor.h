#include "Standard.cpp"
#include "Moderate.cpp"
#include "Superior.cpp"
#include "JuniorSuite.cpp"
#include "Suite.cpp"
class Floor  
{
	private:
		Standard S[10];
		moderate M[10];
		Superior Su[10];
		JuniorSuite J[10];
		Suite St[10];

	public:

		Floor();
		Standard* getStandard();
		moderate* getmoderate();
		Superior* getSuperior();
		JuniorSuite* getJuniorSuite();
		Suite* getSuite();
		~Floor();

};