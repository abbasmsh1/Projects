#include "Suite.h"  
	
Suite::Suite()
{
	setPrice(5000);
    setReserved(false);
}
	
Suite::~Suite()
{
	
}