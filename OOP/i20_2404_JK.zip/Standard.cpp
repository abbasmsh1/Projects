#include "Standard.h"  
	
Standard::Standard()
{
	setPrice(300);
    setReserved(false);
}
	
Standard::~Standard()
{
	cout<<"Standard Room caught fire\n";
}