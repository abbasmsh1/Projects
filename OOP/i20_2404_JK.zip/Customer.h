#include <iostream>
#include <string>
#include "Time.cpp"
using namespace std;
class Customer  
{
	private:
		string FirstName;
		string LastName;
		string FullName;
		int age;
		char gender;
		long int ID;
		double Balance;
		int Days;
		int floorNo;
		int RoomNo;
		Time checkin;
		Time checkout;
		int Remaining;
	public:

		Customer();
		void setFirstName(string);
		void setLastName(string);
		void setFullName();
		void setAge(int);
		void setGender(char);
		void setID(long int);
		void setBalance(double);
		void setDays(int);
		void setFloorNo(int);
		void setRoomNo(int);
		void setCheckin(tm*);
		void setCheckin(Time T);
		void setCheckout(Time T);
		void setCheckout(tm*);
		void setRemaining();
		string getFirstName();
		string getLastName();
		string getFullName();
		int getAge();
		char getGender();
		int getID();
		double getBalance();
		int getDays();
		int getFloorNo();
		int getRoomNo();
		Time getCheckin();
		Time getCheckout();
		int getRemaining();
		void initCustomer();
		void setRoom(int);
		~Customer();

};
