#include "Room.h"
	
class Superior  : public Room
{
	private:

	public:

		Superior();
		~Superior();

};