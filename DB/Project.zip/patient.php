<!DOCTYPE html>
<?php
    $db_user = "lab"; 
    $db_pass = "root";    
    $db_sid = "(DESCRIPTION =
    (ADDRESS = (PROTOCOL = TCP)(HOST = DESKTOP-FIK5SPH)(PORT = 1521))
    (CONNECT_DATA =
      (SERVER = DEDICATED)
      (SERVICE_NAME = Abbas)
    )
  )";
    $con = oci_connect($db_user,$db_pass,$db_sid); 
    if($con) 
      { 
	    echo "connected";
      } 
   else 
      { die('Could not connect to Oracle: '); } 
		$name=0;
      ?>
<html>

<head>
  <!-- Basic -->
  <meta charset="utf-8" />
  <meta http-equiv="X-UA-Compatible" content="IE=edge" />
  <!-- Mobile Metas -->
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
  <!-- Site Metas -->
  <meta name="keywords" content="" />
  <meta name="description" content="" />
  <meta name="author" content="" />
  <link rel="shortcut icon" href="./images/s4.png" type="image/x-icon">

  <title>Hospital</title>

  <!-- bootstrap core css -->
  <link rel="stylesheet" type="text/css" href="./css/bootstrap.css" />

  <!-- fonts style -->
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:400,700|Poppins:400,600,700&display=swap" rel="stylesheet" />
  <!-- nice select -->
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/jquery-nice-select/1.1.0/css/nice-select.min.css" integrity="sha256-mLBIhmBvigTFWPSCtvdu6a76T+3Xyt+K571hupeFLg4=" crossorigin="anonymous" />
  <!-- datepicker -->
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.3.0/css/datepicker.css">
  <!-- Custom styles for this template -->
  <link href="./css/style.css" rel="stylesheet" />
  <!-- responsive style -->
  <link href="./css/responsive.css" rel="stylesheet" />
</head>

<body class="sub_page">
  <div class="hero_area">
    <!-- header section strats -->
    <header class="header_section">
      <div class="container-fluid">
        <nav class="navbar navbar-expand-lg custom_nav-container ">
          <a class="navbar-brand" href="index.html">
            <h3>
              Hospital
            </h3>
          </a>
          <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
          </button>
			
          <div class="collapse navbar-collapse ml-auto" id="navbarSupportedContent">
            <ul class="navbar-nav  ml-auto">
              <li class="nav-item ">
                <a class="nav-link" href="index.html">Home </a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="about.html"> About </a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="service.html"> Services </a>
              </li>
              <li class="nav-item active">
                <a class="nav-link" href="appointment.html">  <span class="sr-only">Patient</span> </a>
              </li>
            </ul>
            <form class="form-inline ">
              <button class="btn nav_search-btn" type="submit">
                <i class="fa fa-search" aria-hidden="true"></i>
              </button>
            </form>
          </div>
        </nav>
      </div>
    </header>
    <!-- end header section -->
  </div>
<?php 
	if(isset($_POST['submit']))
	{
		$sql ="select p.Fname||' '||p.Lname as name,	p.DOB,	nc.Emp_ID,	nc.Fname||' '||nc.Lname as Dname,	c.Fname||' '||c.Lname as Cname from patient p,NonConsultant nc, Consultant c, treatment t
		where p.Patient_ID='".$_POST['PID']."' and p.Patient_ID = t.Patient_ID and t.NonConsultant_ID=nc.NonConsultant_ID and nc.TeamID=c.TeamID";
		$stid = oci_parse($con,$sql);
		oci_execute($stid);
		while ($row = oci_fetch_array($stid, OCI_ASSOC+OCI_RETURN_NULLS))
		{
			$name=$row['name'];
			$DOB=$row['p.DOB'];
			$DID = $row['nc.Emp_ID'];
			$DName=$row['Dname'];
			$Cname=$row['Cname'];
		}
	}
	
	?>
  <!-- book section -->
  <section class="book_section layout_padding">
    <div class="container">
      <div class="row">
        <div class="col">
          <form>
            <h4>
              <span class="design_dot"></span>
            PATIENT RECORD </h4>
            <div class="form-row ">
              <div class="form-group col-lg-4">
                <label for="inputPatientName">Patient No. </label>
                <input type="text" class="form-control" id="inputPatientName" name ="PID" >
              </div>
				<div class="form-group col-lg-4">
                <label for="inputPatientName">Patient Name </label>
                <input type="text" class="form-control" id="inputPatientName" value="<?php echo $name ?>" >
              </div>
				<div class="form-group col-lg-4">
                <label for="inputPatientName">DOB </label>
                <input type="text" class="form-control" id="inputPatientName" value="<?php echo $DOB ?>" >
              </div>
            </div>
            <div class="form-row ">
              <div class="form-group col-lg-4">
                <label for="inputPatientName">Doctor ID </label>
                <input type="text" class="form-control" id="inputPatientName" value ="<?php echo $DID ?>" >
              </div>
              <div class="form-group col-lg-4">
                <label for="inputPatientName">Doctor Name Team</label>
                <input type="text" class="form-control" id="inputPatientName" value ="<?php echo $DName ?>" >
              </div>
              <div class="form-group col-lg-4">
                <label for="inputPatientName">Consultant</label>
                <input type="text" class="form-control" id="inputPatientName" value ="<?php echo $Cname ?>" >
              </div>
            </div>
            <div class="btn-box">
              <button type="submit" class="btn " name = "submit">Submit Now</button>
            </div>
			  <style>
				  .tx{
					  padding: 10px;
					  margin-left: 20px;
					  text-align: center;
				  	}
				  .th{
					  align-content: center;
					  padding: 20px;
				  }
				  .table{
					  	padding: 20px;
						align-content: center;
					  	
					  border-spacing:20px;
				  }
			  </style>
			  <table align="center">
			<th>
				<tx>
					Complaint Code
				</tx>
				  <tx>
				  	Treatment Code
				  </tx>
				  <tx>
				  	Doctor
				  </tx>
				  <tx>
				  	Start Date
				  </tx>
				  
				  <tx>
				  	End Date
				  </tx>
			</th>
				  <?php
						if(isset($_POST['submit']))
					  {
							$sql = " select t.TreatmentCode,t.ComplaintCode,nc.Fname||' '||nc.Lname as name,t.TreatmentStart, t.TreatmentEnd from treatment t, NonConsultant nc
							  where t.Patient_ID='".$_POST['PID']."' and t.NonConsultant_ID=nc.Emp_ID";
							  $stid=oci_parse($con,$sql);
							  oci_execute($stid);
								while ($row = oci_fetch_array($stid, OCI_ASSOC+OCI_RETURN_NULLS))
								{
									echo "<tr>
										  <td>
											".$row['t.ComplaintCode']."
										  </td>
										  <td>
											".$row['t.TreatmentCode']."
										  </td>
										  <td>
											".$row['t.name']."
										  </td>
										  <td>
											".$row['t.TreatmentStart']."
										  </td>
										  <td>
											".$row['t.TreatmentEnd']."
										  </td>
							  </tr>";
								}
						}
				  ?>
				  <tr>
				  <td>
					  
					  </td>
				  </tr>
		</table>
          </form>
			
        </div>
      </div>
		
    </div>
  </section>

  <!-- end book section -->



  <!-- info section -->
  <section class="info_section layout_padding">
    <div class="container">
      <div class="row">
        <div class="col-md-3">
          <div class="info_menu">
            <h5>
              QUICK LINKS
            </h5>
            <ul class="navbar-nav  ">
              <li class="nav-item ">
                <a class="nav-link" href="index.html">Home <span class="sr-only">(current)</span></a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="about.html"> About </a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="service.html"> Services </a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="appointment.html"> Appointment </a>
              </li>
            </ul>
          </div>
        </div>
        <div class="col-md-3">
          <div class="info_course">
            <h5>
              Hospital
            </h5>
            <p>
              There are many variations of passages of Lorem Ipsum available,
              but the majority have suffered alteration in some form, by
              injected humou
            </p>
          </div>
        </div>

        <div class="col-md-5 offset-md-1">
          <div class="info_news">
            <h5>
              FOR ANY QUERY, PLEASE WRITE TO US
            </h5>
            <div class="info_contact">
              <a href="">
                <i class="fa fa-map-marker" aria-hidden="true"></i> Location
              </a>
              <a href="">
                <i class="fa fa-envelope" aria-hidden="true"></i> demo@gmail.com
              </a>
              <a href="">
                <i class="fa fa-phone" aria-hidden="true"></i> Call : +01 1234567890
              </a>
            </div>
            <form action="">
              <input type="text" placeholder="Enter Your email" />
              <button>
                Subscribe
              </button>
            </form>
          </div>
        </div>
      </div>
    </div>
  </section>

  <!-- end info section -->

  <!-- footer section -->
  <footer class="container-fluid footer_section">
    <div class="container"> </div>
  </footer>
  <!-- footer section -->

  <script src="./js/jquery-3.4.1.min.js"></script>
  <script src="./js/bootstrap.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/owl.carousel.min.js"></script>
  <!-- nice select -->
  <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-nice-select/1.1.0/js/jquery.nice-select.min.js" integrity="sha256-Zr3vByTlMGQhvMfgkQ5BtWRSKBGa2QlspKYJnkjZTmo=" crossorigin="anonymous"></script>
  <!-- datepicker -->
  <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.3.0/js/bootstrap-datepicker.js"></script>
  <!-- custom js -->
  <script src="./js/custom.js"></script>
  <!-- Google Map -->
  <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyCh39n5U-4IoWpsVGUHWdqB6puEkhRLdmI&callback=myMap">
  </script>
  <!-- End Google Map -->
</body>

</html>